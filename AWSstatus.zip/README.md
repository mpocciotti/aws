# aws
tests done with AWS
This repository contains tests scripts in Python to interact with AWS
